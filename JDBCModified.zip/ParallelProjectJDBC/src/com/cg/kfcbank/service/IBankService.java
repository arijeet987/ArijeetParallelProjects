package com.cg.kfcbank.service;
import java.util.List;
import com.cg.kfcbank.bean.Bank;
import com.cg.kfcbank.bean.Transaction;
import com.cg.kfcbank.exception.KFCBankException;

public interface IBankService {
	

	public long addCustomer(Bank bank) throws KFCBankException;
	public boolean deposit(long AccNum,double ammount) throws KFCBankException;
	public double showbalance(long AccNum) throws KFCBankException;
	public boolean fundTransfer(long accno1,long accno2,double amount) throws KFCBankException;
	public boolean withdraw(long AccNum,double ammount) throws KFCBankException;
	public Bank accountDetails() throws KFCBankException;
	public List<Transaction> printTransaction(long AccNo) throws KFCBankException;
	public long displayDetails(Long AccNo);
}
