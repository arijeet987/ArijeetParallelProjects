package com.cg.kfcbank.service;
import java.util.List;
import com.cg.kfcbank.bean.Bank;
import com.cg.kfcbank.bean.Transaction;
import com.cg.kfcbank.dao.BankDaoImpl;
import com.cg.kfcbank.dao.IBankDao;
import com.cg.kfcbank.exception.KFCBankException;

public class BankServiceImpl implements IBankService 
{
	IBankDao bankdao = new BankDaoImpl();

	@Override
	public long addCustomer(Bank bank) throws KFCBankException {
		
		return bankdao.addCustomer(bank);
	}

	@Override
	public boolean deposit(long AccNum, double ammount) throws KFCBankException {
		// TODO Auto-generated method stub
		return bankdao.deposit(AccNum, ammount);
	}

	@Override
	public double showbalance(long AccNum) throws KFCBankException {
		// TODO Auto-generated method stub
		return bankdao.showbalance(AccNum);
	}

	@Override
	public boolean fundTransfer(long accno1, long accno2, double amount) throws KFCBankException {
		// TODO Auto-generated method stub
		return bankdao.fundTransfer(accno1, accno2, amount);
	}

	@Override
	public boolean withdraw(long AccNum, double ammount) throws KFCBankException {
		// TODO Auto-generated method stub
		return bankdao.withdraw(AccNum, ammount);
	}

	@Override
	public Bank accountDetails() throws KFCBankException {
		
		return bankdao.accountDetails();
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Transaction> printTransaction(long AccNo) throws KFCBankException {
	
		return bankdao.printTransaction(AccNo);
	}

	@Override
	public long displayDetails(Long AccNo) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
