package com.cg.kfcbank.bean;


	public class Bank {
		
		private static String bankName = "KFC Bank";
		private String accHolderName;
		private String address;
		private long acNum;
		private long mobNum;
		private double balance;
		private String email;
		
		public static String getBankName() {
			return bankName;
		}
		public static void setBankName(String bankName) {
			Bank.bankName = bankName;
		}
		public String getAccHolderName() {
			return accHolderName;
		}
		public void setAccHolderName(String accHolderName) {
			this.accHolderName = accHolderName;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public long getAcNum() {
			return acNum;
		}
		public void setAcNum(long acNum) {
			this.acNum = acNum;
		}
		public long getMobNum() {
			return mobNum;
		}
		public void setMobNum(long mobNum) {
			this.mobNum = mobNum;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		@Override
		public String toString() {
			return "Bank [accHolderName=" + accHolderName + ", address=" + address + ", acNum=" + acNum + ", mobNum="
					+ mobNum + ", balance=" + balance + ", email=" + email + "]";
		}
		
	
		
		
	}


