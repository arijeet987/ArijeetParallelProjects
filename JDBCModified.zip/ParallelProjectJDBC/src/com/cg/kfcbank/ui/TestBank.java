package com.cg.kfcbank.ui;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;

import com.cg.kfcbank.bean.Bank;
import com.cg.kfcbank.exception.KFCBankException;
import com.cg.kfcbank.service.BankServiceImpl;
import com.cg.kfcbank.service.IBankService;

public class TestBank {

		public static void main(String[] args) throws ClassNotFoundException, SQLException, KFCBankException {
			
			IBankService bankservice=new BankServiceImpl();
			
			
				while(true) {
					System.out.println("WELCOME TO SARKAR BANK\n");
					System.out.println("Enter 1 to make account\n");
					System.out.println("Enter 2 balance for deposit\n");
					System.out.println("Enter 3 balance for withdraw\n");
					System.out.println("Enter 4 for display details\n");
					System.out.println("Enter 5 for display Balance\n");
					System.out.println("Enter 6 for fund transfer\n");
					System.out.println("Enter 7 to show all account details\n");
					System.out.println("Enter 8 to print all tranaction\n");
					System.out.println("Enter 9 for exit");
					Scanner sc=new Scanner(System.in);
					int sw = sc.nextInt();
				switch(sw)
				{
				case 1:
					System.out.println("Enter AccountHolder Name:");
					String AccHoldername=sc.next();
					
					System.out.println("Enter  Contact Number:");
					long contact=sc.nextLong();
					
					String mob=contact+"";
					String regEx1="(91|0)?[6-9][0-9]{9}";
					while(!(mob.matches(regEx1)))
					{
						System.out.println("please enter again");
						 contact=sc.nextLong();
						 mob=contact+"";
					}
					
					System.out.println("enter balance:");
					double balance=sc.nextDouble();
					
					System.out.println("Enter Address:");
					double address=sc.nextDouble();
					
					System.out.println("enter Emailid:");
					String email=sc.next();
					String regEx2="[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]{2,})+";
						while(!(email.matches(regEx2)))
					{
						System.out.println("please enter again");
						 email=sc.next();
						
					}
					Bank bank =new Bank();
					bank.setAccHolderName(AccHoldername);
					bank.setAddress(bank.getAddress());
					bank.setMobNum(contact);
					bank.setBalance(balance);
					bank.setEmail(email);
					long accno = bankservice.addCustomer(bank);
					System.out.println("Your Account details are successfully registered and your a/c no is" +accno);
					System.out.println("<h1>Welcome to KFC  bank</h1>");
					break;
					
					
				case 2:
					System.out.println("Enter A/c number:");
					int a1=sc.nextInt();
					System.out.println("Enter ammount to Deposit");
					double amt=sc.nextDouble();
					bankservice.deposit(a1,amt);
					break;
				case 3:
					System.out.println("enter a/c num:");
					int a2=sc.nextInt();
					System.out.println("enter ammount to withdraw");
					double amt1=sc.nextDouble();
					bankservice.withdraw(a2,amt1);
					break;
					
					
				case 4:
					System.out.println("enter a/c num:");
					Long a3=sc.nextLong();
					bankservice.displayDetails(a3);
					break;
					
				case 5:
					System.out.println("enter a/c num:");
					int a4=sc.nextInt();
					System.out.println(bankservice.showbalance(a4));
					break;
					
				case 6:
					System.out.println("enter a/c no from which you want to transfer:");
					int a5=sc.nextInt();
					System.out.println("enter a/c no to whom you want to transfer:");
					int a6=sc.nextInt();
					System.out.println("enter ammount to be transfer:");
					double amt2=sc.nextDouble();
					bankservice.fundTransfer(a5, a6, amt2);
					break;
					
				case 7:
					Bank bankdetails =bankservice.accountDetails();
					System.out.println("your A/c details are:"+bankdetails);
					break;
				case 8:
					System.out.println("enter a/c no to print all the transactions:");
					long a7=sc.nextLong();
					bankservice.printTransaction(a7);
					break;
				case 9:
					System.exit(0);
					break;
					
				}

				}
				
		}

}


